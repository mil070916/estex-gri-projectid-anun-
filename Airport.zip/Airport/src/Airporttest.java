import java.util.Scanner;


public class Airporttest {
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        Plane plane1= new Plane();
        System.out.println("print model");
        String model= scanner.next();
        plane1.setModel("model");
        System.out.println("print country");
        String country= scanner.next();
        plane1.setCountry("country");
        System.out.println("print year");
        int year= scanner.nextInt();
        plane1.setCountry("year");
        System.out.println("print hours");
        int hours= scanner.nextInt();
        plane1.setHours(hours);
        System.out.println("isMilitary");
        boolean isMilitary= scanner.nextBoolean();
        plane1.isMilitary(false);
        System.out.println("print weight");
        float weight= scanner.nextFloat();
        plane1.setWeight(weight);
        System.out.println("print wingspan");
       int wingspan= scanner.nextInt();
        plane1.setWingspan(wingspan);
        System.out.println("print speed");
        float speed= scanner.nextFloat();
        plane1.setSpeed(speed);
        System.out.println("print seats");
        int seats= scanner.nextInt();
        plane1.setSeats(seats);
        System.out.println("print cost");
       float cost= scanner.nextFloat();
        plane1.setCost(cost);

        System.out.println(plane1.getModel());
        System.out.println(plane1.getCountry());
        System.out.println(plane1.getYear());
        System.out.println(plane1.getHours());
        System.out.println(plane1.isMilitary);
        System.out.println(plane1.getWeight());
        System.out.println(plane1.getWingspan());
        System.out.println(plane1.getSpeed());
        System.out.println(plane1.getSeats());
        System.out.println(plane1.getCost());

        plane1.printInfo();

        System.out.println();

        plane1.printInfo(plane1.getCost(10000) && plane1.getSpeed(16000) if(plane1.isMilitary=true): plane1.getModel("S7") && plane1.getCountry(); //task 2:

        Plane plane2= new Plane();
        System.out.println("print model");
        String model2= scanner.next();
        plane2.setModel("model");
        System.out.println("print country");
        String country2= scanner.next();
        plane2.setCountry("country");
        System.out.println("print year");
        int year2= scanner.nextInt();
        plane2.setCountry("year");
        System.out.println("print hours");
        int hours2 = scanner.nextInt();
        plane2.setHours(hours);
        System.out.println("isMilitary");
        boolean isMilitary22= scanner.nextBoolean();
        plane2.isMilitary(false);
        System.out.println("print weight");
        float weight2= scanner.nextFloat();
        plane2.setWeight(weight);
        System.out.println("print wingspan");
        int wingspan2= scanner.nextInt();
        plane2.setWingspan(wingspan);
        System.out.println("print speed");
        float speed2= scanner.nextFloat();
        plane2.setSpeed(speed);
        System.out.println("print seats");
        int seats2= scanner.nextInt();
        plane2.setSeats(seats);
        System.out.println("print cost");
        float cost2= scanner.nextFloat();
        plane1.setCost(cost);

        System.out.println(plane2.getModel());
        System.out.println(plane2.getCountry());
        System.out.println(plane2.getYear());
        System.out.println(plane2.getHours());
        System.out.println(plane2.isMilitary);
        System.out.println(plane2.getWeight());
        System.out.println(plane2.getWingspan());
        System.out.println(plane2.getSpeed());
        System.out.println(plane2.getSeats());
        System.out.println(plane2.getCost());


        Scanner scanner3= new Scanner(System.in);
        Plane plane3= new Plane();
        System.out.println("print model");
        String model3= scanner.next();
        plane3.setModel("model");
        System.out.println("print country");
        String country3= scanner.next();
        plane3.setCountry("country");
        System.out.println("print year");
        int year3 = scanner.nextInt();
        plane3.setCountry("year");
        System.out.println("print hours");
        float hours3= scanner.nextFloat();
        plane3.setHours(hours);
        System.out.println("isMilitary");
        boolean isMilitary3= scanner.nextBoolean();
        plane3.isMilitary(false);
        System.out.println("print weight");
        float weight3= scanner.nextFloat();
        plane3.setWeight(weight);
        System.out.println("print wingspan");
        int wingspan3= scanner.nextInt();
        plane3.setWingspan(wingspan);
        System.out.println("print speed");
        float speed3= scanner.nextFloat();
        plane3.setSpeed(speed);
        System.out.println("print seats");
        int seats3= scanner.nextInt();
        plane3.setSeats(seats);
        System.out.println("print cost");
        float cost3= scanner.nextFloat();
        plane3.setCost(cost);

        System.out.println(plane3.getModel());
        System.out.println(plane3.getCountry());
        System.out.println(plane3.getYear());
        System.out.println(plane3.getHours());
        System.out.println(plane3.isMilitary);
        System.out.println(plane3.getWeight());
        System.out.println(plane3.getWingspan());
        System.out.println(plane3.getSpeed());
        System.out.println(plane3.getSeats());
        System.out.println(plane3.getCost());






    }
}
