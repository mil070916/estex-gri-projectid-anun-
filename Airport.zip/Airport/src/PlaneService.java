import java.util.Scanner;

public class PlaneService {
    Scanner s=new Scanner(System.in);
    Plane plane1 = new Plane();
    Plane plane2=new Plane();
    Plane plane3= new Plane();


}

